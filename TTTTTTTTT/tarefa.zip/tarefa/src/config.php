<?php

define("URL", "http://localhost/teste/tarefa/");